class Product{
  final String id;
  final String name;
  final double price;
  final String imageUrl;
  final String description;
  int stock;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.stock,
    required this.description,
  });
}