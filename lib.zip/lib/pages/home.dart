import 'package:flutter/material.dart';
import '../models/product.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  
  double _balance = 0.0;
  String _displayMessage = '';
  String _inputCode = "";

  List<Product> products = [
    Product(
      id: '1',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '2',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '3',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '4',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '5',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '6',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '7',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '8',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '9',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '10',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '11',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '12',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '13',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '14',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '15',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '16',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '17',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '18',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '19',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '20',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '21',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '22',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '23',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '24',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '25',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '26',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '27',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '28',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '29',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '30',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '31',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '32',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '33',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '34',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '35',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '36',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '37',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '38',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '39',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '40',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '41',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '42',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '43',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '44',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '45',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '46',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '47',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '48',
      name: 'Product 3',
      description: 'Description of Product 3',
      price: 30.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '49',
      name: 'Product 1',
      description: 'Description of Product 1',
      price: 10.0,
      stock: 1,
      imageUrl: ''
    ),
    Product(
      id: '50',
      name: 'Product 2',
      description: 'Description of Product 2',
      price: 20.0,
      stock: 1,
      imageUrl: ''
    )
  ];
  
// ฟังก์ชันแสดง Pop-up (showDialog)
  void _showResultDialog(String title, String message, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Row(
            children: [
              Icon(
                isSuccess ? Icons.check_circle : Icons.error,
                color: isSuccess ? Colors.green : Colors.red,
              ),
              const SizedBox(width: 8),
              Text(title, style: TextStyle(color: isSuccess ? Colors.green : Colors.red)),
            ],
          ),
          content: Text(message, style: const TextStyle(fontSize: 16)),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isSuccess ? Colors.green : Colors.red,
              ),
              onPressed: () => Navigator.pop(context),
              child: const Text("ตกลง", style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  // หยอดเงิน
  void _insertCoin(double amount) {
    setState(() {
      _balance += amount;
    });
  }

  // กดปุ่มเลือกเลข
  void _pressKey(String char) {
    setState(() {
      if (_inputCode.length < 2) {
        _inputCode += char;
      }
    });
  }

  // เคลียร์ค่า
  void _clearInput() {
    setState(() {
      _inputCode = "";
    });
  }

  // กดยืนยัน (OK)
  void _buyProduct() {
    final index = products.indexWhere((p) => p.id == _inputCode);

    if (index == -1) {
      _showResultDialog("รหัสไม่ถูกต้อง", "กรุณาตรวจสอบรหัสสินค้าใหม่อีกครั้ง");
      return;
    }

    final product = products[index];
    
    if (product.stock == 0) {
      _showResultDialog("สินค้าหมด", "สินค้า ${product.name} หมดสต็อกแล้ว");
    } else if (_balance < product.price) {
      final needMore = product.price - _balance;
      _showResultDialog("เงินไม่พอ", "ราคารวม ฿${product.price.toStringAsFixed(0)}\nต้องการเงินเพิ่มอีก ฿${needMore.toStringAsFixed(0)}");
    } else {
      // ทำรายการสำเร็จ
      final change = _balance - product.price;
      setState(() {
        product.stock--;
        _balance = 0; // คืนเงินที่เหลือทั้งหมดพร้อมทอน
        _inputCode = "";
        
      });

      _showResultDialog(
        "ทำรายการสำเร็จ",
        "รับสินค้า: ${product.name}\nเงินทอนทั้งหมด: ฿${change.toStringAsFixed(0)}",
        isSuccess: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Vending Machine")),
      body: Center(
        child: Container(
          width: 550,
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            color: Colors.red.shade800,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black45)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 1. จอ LED แสดงสถานะเงิน และ รหัสที่เลือก
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Text("CREDIT: ฿${_balance.toStringAsFixed(0)}",
                        style: const TextStyle(color: Colors.yellowAccent, fontSize: 16, fontFamily: 'monospace')),
                    Text("CODE: $_inputCode",
                        style: const TextStyle(color: Colors.greenAccent, fontSize: 16, fontFamily: 'monospace')),
                  ],
                ),
              ),
              const SizedBox(height: 15),

              // 2. ตัวตู้: แบ่งซ้าย (สินค้าเลื่อนได้) / ขวา (แผงควบคุม)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- โซนซ้าย: รายการสินค้าแบบเลื่อนได้ (Scrollable Grid) ---
                  Expanded(
                    flex: 3,
                    child: Container(
                      height: 340,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Scrollbar(
                        thumbVisibility: true,
                        child: GridView.builder(
                          physics: const AlwaysScrollableScrollPhysics(), // ให้เลื่อนได้ตลอดเวลา
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.72,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: products.length,
                          itemBuilder: (context, i) {
                            final p = products[i];
                            return Container(
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey.shade300),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: p.imageUrl.isNotEmpty
                                          ? Image.network(p.imageUrl, fit: BoxFit.contain)
                                          : const Icon(Icons.image, size: 40, color: Colors.grey),
                                    ),
                                  ),
                                  Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                  Text("฿${p.price.toStringAsFixed(0)}", style: const TextStyle(color: Colors.green, fontSize: 12)),
                                  Text("Stock: ${p.stock}", style: TextStyle(color: p.stock > 0 ? Colors.grey : Colors.red, fontSize: 10)),
                                  Container(
                                    margin: const EdgeInsets.only(top: 2, bottom: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                    color: Colors.black,
                                    child: Text(p.id, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                                  )
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // --- โซนขวา: ใส่เงิน + ปรับจำนวน + ปุ่มกด ---
                  Expanded(
                    flex: 2,
                    child: Column(
                      children: [
                        // หยอดเงิน
                        const Text("INSERT COIN", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton(onPressed: () => _insertCoin(10), child: const Text("10")),
                            ElevatedButton(onPressed: () => _insertCoin(20), child: const Text("20")),
                          ],
                        ),
                        const Divider(color: Colors.white54, height: 16),

                        // ปรับจำนวนของ (Quantity)
                       
                        const Divider(color: Colors.white54, height: 16),

                        // ปุ่มกดเลือกรหัส
                        Wrap(
                          spacing: 4,
                          runSpacing: 4,
                          children: ["1", "2", "3", "4", "5", "6"].map((char) {
                            return SizedBox(
                              width: 32,
                              height: 32,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(padding: EdgeInsets.zero),
                                onPressed: () => _pressKey(char),
                                child: Text(char),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 12),

                        // ปุ่ม Cancel & OK
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, padding: EdgeInsets.zero),
                                onPressed: _clearInput,
                                child: const Text("C", style: TextStyle(color: Colors.white)),
                              ),
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: EdgeInsets.zero),
                                onPressed: _buyProduct,
                                child: const Text("OK", style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 15),

              // ช่องรับสินค้า
              Container(
                width: double.infinity,
                height: 35,
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Center(
                  child: Text("PUSH (PUSH TO RECEIVE ITEM)", style: TextStyle(color: Colors.white38, fontSize: 11)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}